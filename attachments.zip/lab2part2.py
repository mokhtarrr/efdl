from torchvision.datasets import CIFAR10
import numpy as np 
import torchvision.transforms as transforms
import torch 
from torch.utils.data.dataloader import DataLoader
import torchvision 
from torch import nn, optim
import torch.nn.functional as F 
from torch.optim import lr_scheduler
import matplotlib.pyplot as plt
import cifar10.pytorch_cifar.models
import time
import binaryconnect
## Normalization adapted for CIFAR10
normalize_scratch = transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))

# Transforms is a list of transformations applied on the 'raw' dataset before the data is fed to the network. 
# Here, Data augmentation (RandomCrop and Horizontal Flip) are applied to each batch, differently at each epoch, on the training set data only
transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    normalize_scratch,
])

transform_test = transforms.Compose([
    transforms.ToTensor(),
    normalize_scratch,
])
### The data from CIFAR10 will be downloaded in the following folder
rootdir = '/users/local/data'

c10train = CIFAR10(rootdir,train=True,download=True,transform=transform_train)
c10test = CIFAR10(rootdir,train=False,download=True,transform=transform_test)

trainloader = DataLoader(c10train,batch_size=32,shuffle=True)
testloader = DataLoader(c10test,batch_size=32) 
## number of target samples for the final dataset
num_train_examples = len(c10train)
num_samples_subset = 15000

## We set a seed manually so as to reproduce the results easily
seed  = 2147483647

## Generate a list of shuffled indices ; with the fixed seed, the permutation will always be the same, for reproducibility
indices = list(range(num_train_examples))
np.random.RandomState(seed=seed).shuffle(indices)## modifies the list in place

## We define the Subset using the generated indices 
c10train_subset = torch.utils.data.Subset(c10train,indices[:num_samples_subset])
print(f"Initial CIFAR10 dataset has {len(c10train)} samples")
print(f"Subset of CIFAR10 dataset has {len(c10train_subset)} samples")

# Finally we can define anoter dataloader for the training data
trainloader_subset = DataLoader(c10train_subset,batch_size=32,shuffle=True)
### You can now use either trainloader (full CIFAR10) or trainloader_subset (subset of CIFAR10) to train your networks.
#model = torchvision.models.resnet18(pretrained=True)

model = cifar10.pytorch_cifar.models.ResNet18()
### define your model somewhere, let's say it is called "mymodel"

mymodelbc = binaryconnect.BC(model) ### use this to prepare your model for binarization 
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
mymodelbc.model = mymodelbc.model.to(device) # it has to be set for GPU training 
optimizer = optim.SGD(model.parameters(), lr=0.1, weight_decay=1e-3) 
', momentum=0.9, weight_decay=1e-5'
', weight_decay=1e-5'
criterion = nn.CrossEntropyLoss()
Previousloss=0
exp_lr_scheduler = lr_scheduler.StepLR(optimizer, step_size=50, gamma=0.1)
### During training (check the algorithm in the course and in the paper to see the exact sequence of operations)
n_epochs=100
training_start_time = time.time()
for epoch in range(n_epochs):
    correct = 0
    total = 0
    for data, label in trainloader_subset:
        data, label=data.to(device), label.to(device)
        optimizer.zero_grad()
        mymodelbc.binarization() ## This binarizes all weights in the model
        prediction = model(data)
        loss = criterion(prediction, label)
        #print(loss)
        loss.backward()
        mymodelbc.restore() ###  This reloads the full precision weights
        optimizer.step()
        mymodelbc.clip()
        _, predicted = torch.max(prediction.data, 1)
        predicted=predicted.to(device)
        total += label.size(0)
        correct += (predicted == label).sum().item()
    print('Accuracy of the network on the 15000 train images: %d %%' % (
    100 * correct / total))
    exp_lr_scheduler.step()
correct = 0
total = 0
model.eval()
with torch.no_grad():  # torch.no_grad for TESTING
    for data in testloader:
        images, labels = data
        images, labels=images.to(device), labels.to(device)
        outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)
        predicted=predicted.to(device)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

print('Accuracy of the network on the 10000 test images: %d %%' % (
    100 * correct / total))
PATH = './lab2_bin.pth'
torch.save(model.state_dict(), PATH)



