from torchvision.datasets import CIFAR10
import numpy as np 
import torchvision.transforms as transforms
import torch 
from torch.utils.data.dataloader import DataLoader
import torchvision 
from torch import nn, optim
import torch.nn.functional as F 
from torch.optim import lr_scheduler
from torchinfo import summary
import matplotlib
import matplotlib 
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import cifar10.pytorch_cifar.models
import resenet_modifications.models3
import resenet_modifications.models2
import resenet_modifications.models

model1 = cifar10.pytorch_cifar.models.ResNet18()
#model1.fc=nn.Linear(512, 10)
#batch_size = 32
#summary(model, input_size=(batch_size, 3, 32, 32))
#print(summary.params)
total_params1 = sum(
	param.numel() for param in model1.parameters()
)
print(total_params1)
model2 = resenet_modifications.models.ResNet18()
#model2.classifier[6]=nn.Linear(4096, 10)
#print(model2)
#batch_size = 32
#summary(model, input_size=(batch_size, 3, 32, 32))
#print(summary.params)
total_params2 = sum(
	param.numel() for param in model2.parameters()
)
print(total_params2)
model3 = resenet_modifications.models2.ResNet18()
#model3.classifier=nn.Linear(1024, 10)
#print(model3)
#batch_size = 32
#summary(model, input_size=(batch_size, 3, 32, 32))
#print(summary.params)
total_params3 = sum(
	param.numel() for param in model3.parameters()
)
print(total_params3)
model4 = resenet_modifications.models.ResNet18()
#model4.classifier[6]=nn.Linear(4096, 10)
print(model4)
#batch_size = 32
#summary(model, input_size=(batch_size, 3, 32, 32))
#print(summary.params)
total_params4 = sum(
	param.numel() for param in model4.parameters()
)
print(total_params4)
X=[total_params1/10**6,total_params2/10**6,total_params3/10**6,total_params4/10**6]
y=[84, 84, 84, 84]
plt.plot(X,y, "b.")
plt.xlabel("Number of model parameters(M)", fontsize=18)
plt.ylabel("Top 1 Accuracy(%)", rotation=90, fontsize=18)
plt.text(X[0], y[0], 'without modification')
plt.text(X[1], y[1], 'one layer removed')
plt.text(X[2], y[2], 'one layer added')
plt.text(X[3], y[3], 'changing the width')
plt.title('using SGD as optimizer')
plt.show()
plt.savefig('acc_param_SGD.png')